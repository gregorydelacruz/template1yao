package table

// Export process & api
func Export() error {
	exportProcess()
	return exportAPI()
}
