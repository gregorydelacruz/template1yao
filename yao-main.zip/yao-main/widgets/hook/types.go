package hook

// Before before:search ...
type Before string

// After  after:search ...
type After string
