package dashboard

// Validate table
func (dsl *DSL) Validate() error {
	return nil
}
