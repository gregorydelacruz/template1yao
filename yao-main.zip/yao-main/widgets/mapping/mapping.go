package mapping

// Mapping common
type Mapping struct {
	Filters map[string]string
	Columns map[string]string
	Actions map[string]string
}
