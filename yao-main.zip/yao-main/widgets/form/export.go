package form

// Export process & api
func Export() error {
	exportProcess()
	return exportAPI()
}
