package form

// Validate table
func (dsl *DSL) Validate() error {
	return nil
}
