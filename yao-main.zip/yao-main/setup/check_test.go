package setup

import (
	"testing"
)

func TestValidate(t *testing.T) {
	// err := Validate()
	// fmt.Println(err)

	// if err != nil {
	// 	t.Fatal(err)
	// }
}
