package message

// makeMessage create a new message
func makeMessage() *Message {
	return &Message{Actions: []Action{}}
}
